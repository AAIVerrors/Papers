Attached are the raw results from our benchmarks.

CRPS: Continuous Ranked Probability Score as computed by GluonTS using the "mean_wQuantileLoss" metric
ND: Normalized Mean Absolute Error
NRMSE: Normalized Root-Mean-Square Error, normalized by the target mean
MSE: Mean Square Error
?-Sum: same metrics as above, but computed on the per time step sums
Energy: energy score

The backtesting_id correspond to the following backtesting timestamps:
electricity:
0-> 2014-11-17 00:00:00
1-> 2014-11-24 00:00:00
2-> 2014-12-01 00:00:00
3-> 2014-12-08 00:00:00
4-> 2014-12-15 00:00:00
5-> 2014-12-22 00:00:00
fred-md:
0-> 2013-01
1-> 2014-01
2-> 2015-01
3-> 2016-01
4-> 2017-01
5-> 2018-01
kdd-cup:
0-> 2018-01-01 00:00:00
1-> 2018-01-15 00:00:00
2-> 2018-01-29 00:00:00
3-> 2018-02-12 00:00:00
4-> 2018-02-26 00:00:00
5-> 2018-03-12 00:00:00
solar-10min:
0-> 2006-11-20 00:00:00
1-> 2006-11-27 00:00:00
2-> 2006-12-04 00:00:00
3-> 2006-12-11 00:00:00
4-> 2006-12-18 00:00:00
5-> 2006-12-25 00:00:00
traffic:
0-> 2006-11-14 00:00:00
1-> 2006-11-21 00:00:00
2-> 2006-11-28 00:00:00
3-> 2006-12-05 00:00:00
4-> 2006-12-12 00:00:00
5-> 2006-12-19 00:00:00
